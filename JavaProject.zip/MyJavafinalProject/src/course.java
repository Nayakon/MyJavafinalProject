
public class course {

    public course(String courseName,int value){
        this.courseName = courseName;
        this.value = value;
    }
    String courseName;
    int value;

}

