  enum Status  {MARRIED, SINGLE, DIVORCED,UNKNOWN}



